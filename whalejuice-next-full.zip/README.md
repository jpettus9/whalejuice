# WhaleJuice — Next.js Demo

Pages:
- `/` Landing page
- `/event` Sportsbook Event demo (fake bankroll, SGP builder)

## Run locally
```bash
npm install
npm run dev
# open http://localhost:3000
```

## Deploy via GitHub → CodeSandbox
1. Create a new public repo (empty).
2. Upload all files/folders from this project into the repo root.
3. Open: `https://codesandbox.io/p/github/<your-user>/<your-repo>`
